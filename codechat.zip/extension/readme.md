To install this extension read:

Navigate to chrome://extensions
Expand the developer dropdown menu and click "Load Unpacked Extension"
Navigate to local folder
Assuming there are no errors, the extension should load into your browser


http://superuser.com/questions/247651/how-does-one-install-an-extension-for-chrome-browser-from-the-local-file-system

Hay que cambiar el logo (icon.png) ese es uno temporal